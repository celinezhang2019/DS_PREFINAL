# current tensorflow version is 1.14 keras 2.2.5 
import base64
import numpy as np
import io
from PIL import Image
import keras
from keras import backend as K
from keras.models import Sequential
from keras.models import load_model
from keras.preprocessing.image import ImageDataGenerator
from keras.preprocessing.image import img_to_array
from flask import request
from flask import jsonify
from flask import Flask
from keras import applications
import keras
import keras.backend as K
from keras.models import Model
from keras.layers import Input, Dense, Conv2D, Conv3D, DepthwiseConv2D, SeparableConv2D, Conv3DTranspose
from keras.layers import Flatten, MaxPool2D, AvgPool2D, GlobalAvgPool2D, UpSampling2D, BatchNormalization
from keras.layers import Concatenate, Add, Dropout, ReLU, Lambda, Activation, LeakyReLU, PReLU
from keras.utils import np_utils
from IPython.display import SVG
from keras.utils.vis_utils import model_to_dot
from keras.optimizers import SGD
from time import time
from keras.callbacks import EarlyStopping
from sklearn.metrics import confusion_matrix, f1_score, precision_score, recall_score
from keras.callbacks import Callback

import numpy as np
import pandas as pd
import matplotlib, os, math

import os
import uuid
import shutil
import zipfile
from flask import render_template

# celine add according to: https://blog.csdn.net/qq_36213248/article/details/90049915
import tensorflow as tf
global graph,model
graph = tf.get_default_graph()
# graph = tf.compat.v1.get_default_graph() # if tensorflow 2.0 version


app = Flask(__name__)

BASE_DIR = "/home/zxt/code/final/web/flask_apps/testzip1" 
# BASE_DIR = "/Users/zxt/Desktop/web_app/origin/testzip1" 
#os.path.dirname(os.path.abspath(__file__))


def walkFile(file):
    for root, dirs, files in os.walk(file):

        # root is the current loaction
        # dirs is subfolders list
        # files is file list 

        # ????
        for f in files:
            filePath = os.path.join(root, f)
            if(filePath.endswith('.png')):
                print(filePath)

def unzip_file(zip_src, dst_dir):
    """
    Should be zip file
    :param zip_src: zip file address
    :param dst_dir: target file to unzip
    :return:
    """
    r = zipfile.is_zipfile(zip_src)
    if r:
        fz = zipfile.ZipFile(zip_src, "r")
        for file in fz.namelist():
            fz.extract(file, dst_dir)
    else:
        return "Please upload a zip file!"
    
def alexnet(input_shape, n_classes):
    input = Input(input_shape)
  
    # actually batch normalization didn't exist back then
    # they used LRN (Local Response Normalization) for regularization
    x = Conv2D(96, 11, strides=4, padding='same', activation='relu')(input)
    x = BatchNormalization()(x)
    x = MaxPool2D(3, strides=2)(x)
  
    x = Conv2D(256, 5, padding='same', activation='relu')(x)
    x = BatchNormalization()(x)
    x = MaxPool2D(3, strides=2)(x)
  
    x = Conv2D(384, 3, strides=1, padding='same', activation='relu')(x)
  
    x = Conv2D(384, 3, strides=1, padding='same', activation='relu')(x)
  
    x = Conv2D(256, 3, strides=1, padding='same', activation='relu')(x)
    x = BatchNormalization()(x)
    x = MaxPool2D(3, strides=2)(x)
  
    x = Flatten()(x)
    x = Dense(4096, activation='relu')(x)
    x = Dense(4096, activation='relu')(x)
  
    output = Dense(n_classes, activation='softmax')(x)
  
    model = Model(input, output)
    return model


input_shape = 224,224,3
n_classes=5
def create_model():
    model = alexnet(input_shape, n_classes)
    learning_rate = 0.01
    decay_rate = learning_rate / 5
    momentum = 0.8
    sgd = SGD(lr=learning_rate, momentum=momentum, decay=decay_rate, nesterov=False)
    model.compile(loss='categorical_crossentropy',optimizer=sgd,metrics=['accuracy'])
    return model



    
def get_model():
    global model
    model = create_model()
    

#     model = load_model('model_vgg2.h5')
    model.load_weights('/home/zxt/code/final/web/flask_apps/model_weights.ckpt')
    print(" * Model loaded!")
    return model

def preprocess_image(image, target_size):
    if image.mode != "RGB":
        image = image.convert("RGB")
    image = image.resize(target_size)
    image = img_to_array(image)
    image = np.expand_dims(image, axis=0)
    image /= 255.

    return image

print(" * Loading Keras model...")
get_model()

@app.route("/dictionary", methods=["POST"])
def dictionary():
    message = request.get_json(force=True)
    prediction_id = message['prediction_id']
    print("#prediction_id=" + prediction_id)
    
    #print("#walkFile")
    #walkFile(BASE_DIR + '/' + prediction_id)
    
    response = {
        'prediction': []
    }
    
    prediction_id_direction = BASE_DIR + '/' + prediction_id #walk through the unzipped file 
    for root, dirs, files in os.walk(prediction_id_direction):
        for f in files:
            filePath = os.path.join(root, f)
            print("#filePath=" + filePath)
            print(filePath.count('__MACOSX'))
            if (os.path.exists(filePath)):
                if((filePath.endswith('.jpg') or filePath.endswith('.jpeg') or filePath.endswith('.png')) and filePath.count('__MACOSX')==0):
                    image = Image.open(filePath)
                    processed_image = preprocess_image(image, target_size=(224,224))

                    with graph.as_default():
                        prediction = model.predict(processed_image).tolist()
                              
                           
                    prediction_item = {
                        'fileName': f,
                        'elephant': prediction[0][0],
                        'wild_boar': prediction[0][1],
                        'gazellethomosons': prediction[0][2],
                        'squirrel': prediction[0][3],
                        'hedgehog': prediction[0][4],
    
                        'guineafowl': prediction[0][5],
                        'moose': prediction[0][6],
                        'coyote': prediction[0][7],
                        'bird': prediction[0][8],
                        
                        'fox': prediction[0][9],
                        'giraffe': prediction[0][10],
                        'bufallo': prediction[0][11],
                        'hare': prediction[0][12],
                        
                        'vehicle': prediction[0][13],
                        'wildebeest': prediction[0][14],
                        'cattle': prediction[0][15],
                        'skunk': prediction[0][16],
                         
                        'lion': prediction[0][17],
                        'zebra': prediction[0][18],
                        'black_bear': prediction[0][19],
                        'racoon': prediction[0][20],
                        'empty': prediction[0][21]
                        
                    }
                    
                    #http://osask.cn/front/ask/view/4047678
                    response['prediction'].append(prediction_item)
                    
    print("#response")
    print(response)
    return jsonify(response)


@app.route("/predict", methods=["POST"])
def predict():
    message = request.get_json(force=True)
    encoded = message['image']
    decoded = base64.b64decode(encoded)
    image = Image.open(io.BytesIO(decoded))
    processed_image = preprocess_image(image, target_size=(224,224))
    
    with graph.as_default():
        prediction = model.predict(processed_image).tolist()

    response = {
        'prediction': [{

            'elephant': prediction[0][0],
            'wild_boar': prediction[0][1],
            'gazellethomosons': prediction[0][2],
            'squirrel':prediction[0][3],
            'hedgehog': prediction[0][4],
    
            'guineafowl': prediction[0][5],
            'moose': prediction[0][6],
            'coyote': prediction[0][7],
            'bird': prediction[0][8],
                        
            'fox': prediction[0][9],
            'giraffe': prediction[0][10],
            'bufallo': prediction[0][11],
            'hare': prediction[0][12],
                        
            'vehicle': prediction[0][13],
            'wildebeest': prediction[0][14],
            'cattle': prediction[0][15],
            'skunk': prediction[0][16],
                
            'lion': prediction[0][17],
            'zebra': prediction[0][18],
            'black_bear': prediction[0][19],
            'racoon': prediction[0][20],
            'empty': prediction[0][21]


        },
        {
      
            'elephant': prediction[0][0],
            'wild_boar': prediction[0][1],
            'gazellethomosons': prediction[0][2],
            'squirrel': prediction[0][3],
            'hedgehog': prediction[0][4],
    
            'guineafowl': prediction[0][5],
            'moose': prediction[0][6],
            'coyote': prediction[0][7],
            'bird': prediction[0][8],
                        
            'fox': prediction[0][9],
            'giraffe': prediction[0][10],
            'bufallo': prediction[0][11],
            'hare': prediction[0][12],
                        
            'vehicle': prediction[0][13],
            'wildebeest': prediction[0][14],
            'cattle': prediction[0][15],
            'skunk': prediction[0][16],
                
            'lion': prediction[0][17],
            'zebra': prediction[0][18],
            'black_bear': prediction[0][19],
            'racoon': prediction[0][20],
            'empty': prediction[0][21]
        }]
    }
    return jsonify(response)


# according to the method : https://www.cnblogs.com/believepd/p/10339394.html
@app.route("/upload", methods=["POST"])
def upload():
    #if request.method == "GET":
    #    return render_template("upload.html")
    obj = request.files.get("file")
    print(obj)  # <FileStorage: "test.zip" ("application/x-zip-compressed")>
    print("filename:" + obj.filename)  # test.zip
    print(obj.stream)  # <tempfile.SpooledTemporaryFile object at 0x0000000004135160>
    # check if the pre upload file is zip file type:
    ret_list = obj.filename.rsplit(".", maxsplit=1)
    if len(ret_list) != 2:
        return "Please upload a zip file."
    if ret_list[1] != "zip":
        return "Please upload a zip file."

    # method1: save the file directly
    # obj.save(os.path.join(BASE_DIR, obj.filename))
    
    # method3: save the zip file to local, and then unzip it , finally delete the zip file
    file_path = os.path.join(BASE_DIR, obj.filename)  # the path keeps the uploaded file
    obj.save(file_path)
    target_dictionary = str(uuid.uuid4())
    print("target_dictionary1=" + target_dictionary)
    target_path = os.path.join(BASE_DIR, target_dictionary)  # unzipped file location
    ret = unzip_file(file_path, target_path)
    #os.remove(file_path)  # delete the zip file
    print("target_dictionary2")
    #if ret:
    #    return ret
    
    response = {
        'result': '[' + obj.filename + '] Successfully uploaded.Press Predict to classify.',
        'prediction_id': target_dictionary
    }
    print("target_dictionary3")
    print(response)
    print("target_dictionary4")
    print(jsonify(response))
    print("target_dictionary5")
    return jsonify(response)
